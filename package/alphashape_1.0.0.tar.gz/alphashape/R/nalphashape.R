
##' @title alphaShape
##' @description Compute an alpha Shape Grid using the Q-hull library. 
##' @param voronoiObject Object containing the trigulation, inputpoint, voronoi vertices and circumradii returned from the voronoi function. voronoiObject is produce using the function \code{\link{voronoi}}
##' @param alphaRange, range of alpha value
##' @param n \code{n} number of point to generate for this grid
##' @details The calculation is done by assigning the trigulation index when the grid cell center lies within the trigulation or -1 if it lies outside 
##' @return grid stack as vector, gridSimplex, and the inputted grid point.
##' @example 
##'  x = c(30,70,20,50,40,70)
##'  y = c(35,80,70,50,60,20)
##'  p = matrix(c(x,y), ncol=2)
##'  voronoi(point =p)
##'  nalphaShape(v,c(1;20),n=10)
#' @export nalphaShape
nalphaShape <- function(voronoiObject,alphaRange,n=NULL) {
	
	tmpdir <- tempdir()
	## check if R tmpdir is writable
	if (file.access(tmpdir, 2) == -1) {
		stop(paste("Unable to write to R temporary directory", tmpdir, "\n"))
	}
	
	## check to make sure input are not null
	if(is.null(voronoiObject)){
		stop(paste("Voronoi object should not be null", "\n"))
		
	}
	if(is.vector(alphaRange))
		alphaRange <- as.list(alphaRange) #change alpha range value to list
	
	
	if(typeof(alphaRange) != "list"){
		stop(paste("alpha range is not a list", "\n"))
	}
	dim = ncol(voronoiObject$voronoiVertices) # we can get the number of dimension from the Number of col on the voronoi vertices list
	tri = voronoiObject$tri
	circumRadii = voronoiObject$circumRadii
	inputPoint=voronoiObject$inputPoints
	center = voronoiObject$voronoiVertices
	colD = dim+1
	
	
	#create mesh grid
	meshGrdiSpace = gridGeneration(point=inputPoint,n=n)
	
	
	if(!is.matrix(meshGrdiSpace)){
		stop("Test input point is not a matrix ");
	}
	
	#Secondly, each point which is inside the convex hull is now check to determine if the center lies in any of the trigulation, and if found the trigulation index is return
	gridSpaceSimplex <- findSimplex(tri, inputPoint,meshGrdiSpace)
	
	
	alphaComplexSimplicesList =NULL
	resultList=list()
	emptyGrid <- ifelse(gridSpaceSimplex !=0,0,gridSpaceSimplex)
	#for each alpha , Identify those simplices that will form the alpha-shape
	for(alpha in alphaRange){	
		alphaComplexSimplices= which(circumRadii<alpha)
		alphaComplexSimplices =alphaComplexSimplices -1
		
		j=1
		sp=NULL
		for(value in gridSpaceSimplex){
			
			if(! value %in% alphaComplexSimplices)
				sp[j] = 0
			else{
				sp[j]=1
			}
			
			j<-j+1
		}
		emptyGrid =emptyGrid+sp
		
	}
	#return alpha grid as matrix
	alphaGridMatrix = matrix(emptyGrid ,ncol=n,byrow=TRUE)
	return (list(alphaGrid=alphaGridMatrix,gridSpace=meshGrdiSpace,gridSpaceSimplex =gridSpaceSimplex))
}


#Internal function use by \code{\link{findSimplex}} to calculate the bycentri co-ordinate
getBycentriCoordinate <- function(X, P) {
	M <- nrow(P)
	N <- ncol(P)
	if (ncol(X) != N) {
		stop("Simplex X must have same number of columns as point matrix P")
	}
	if (nrow(X) != (N+1)) {
		stop("Simplex X must have N columns and N+1 rows")
	}
	X1 <- X[1:N,] - (matrix(1,N,1) %*% X[N+1,,drop=FALSE])
	if (rcond(X1) < .Machine$double.eps) {
		warning("Degenerate simplex")
		return(NULL)
	}
	Beta <- (P - matrix(X[N+1,], M, N, byrow=TRUE)) %*% solve(X1)
	Beta <- cbind(Beta, 1 - apply(Beta, 1, sum))
	return(Beta)
}


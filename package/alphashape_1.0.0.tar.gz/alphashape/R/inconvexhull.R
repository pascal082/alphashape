##' @title in convex hull
##'
##' @description  To test if a given point is inside the convex hull. \code{TRUE}  if the point  lies within the hull and \code{FALSE} if it
##' lies outwith the hull 
##' 
##' @param  hull object Convex hull simplices produced using convex function
##' @param points: matrix  \code{n}-by-\code{dim} matrix of points to check. 
##' @return A \code{n*m} vector containing the result. True if a given point was inside the convexhull , otherwise false
##' @example 
##' x = c(30,70,20,50,40,70)
##' y = c(35,80,70,50,60,20)
##' p = matrix(c(x,y), ncol=2)
##' convex =convex(point=p)
##' #point to check
##' p2 = matrix(c(c(20,40,20,40),c(60,80,20,20)), ncol=2) 
##' inconvexhull(convex,p2)
#' @export inconvexhull
inconvexhull <- function(hull, points) {
	
	if(!is.matrix(points)){
		stop("Test input point is not a matrix ");
	}
	
	if(!is.matrix(hull$convexhull)){
		stop("convex hull point produce is not a matrix. Please make sure you are passing the convex hull object ");
	
	}
	
	
	return(.Call("C_inconvexhull", hull$convexhull, points, PACKAGE="alphashape"))
}
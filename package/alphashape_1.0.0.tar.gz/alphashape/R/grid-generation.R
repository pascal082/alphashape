
##' @title  gridGeneration
##' @description Generate a \code{n*m} grid point by passing the vector of max and min point or file containing the initial data point or a matrix of input point 
##' @param inputfile file name containing the input point and number of dimension
##' @param Point: Matrix. The input point. 
##' @param nCoords \code{n} number of coordinates across the grid 
##' @param minPoint Vector of length \code{n} listing the  minimum point for each dimension.
##' @param maxPoint Vector of length \code{n} listing the  maximum point for each dimension.
##' @details  This function creates a grid by using the max/min values specify by the user. Note that when the user sepcify a matrix of point the maximum and minimum point will
##'           be derived from the input point and use when generating the grid (+ 0.3 is added to the max point, and -0.-3 is taken away from the min point). 
##' Point could be passed as a file or matrix of point
##' @return A \code{n*m} vector of matrix
#'  @export gridGeneration

gridGeneration <- function(inputFile=NULL,point=NULL,nCoords,minPoint=NULL,maxPoint=NULL) {
  
  
  paste("reading inputFile",inputFile)
  
  if(is.null(inputFile) && is.null(point) && is.null(minPoint) && is.null(maxPoint)){ 
    stop("please specify at least one file source, and this should be file name containing the point or point as matrix or vector of list of max/min point.")
  }
  
  #check to make sure grid size is greather than 1
  if (is.null(nCoords) || nCoords <= 1) {
    stop("Grid size must be greater than one")
  }
  
  
  ## Coerce the input to be matrix
  #user specify to read point from matrix
  if(is.null(inputFile) && !is.null(point)){  
    point <- as.matrix(point)
    dim= ncol(point)
    
    #check to make sure dimension is between 2 and 9
    if(!dim >= 2){
      stop(paste("point dimension on input point must be between 2 and 9",  "\n"))
    }
    
    #check to make sure we have the required point for the number of dimension specify, hence Qhull will return an error
    numberOfPointRequired =dim +2
    
    if(length(point) < numberOfPointRequired){
      stop("You need at least ", numberOfPointRequired, " point for ", dim , "  dimension")
    }
    
    #create the max/min point vector to use
    maxPoint=c()
    minPoint=c()
    for(i in c(1:dim)){
      #get the max/min value for each column
      maxPoint[i] = max(point[,i])
      minPoint[i] = min(point[,i])
    }
    ## Make sure we have real-valued input
    storage.mode(point) <- "double"
    
  }else if(!is.null(inputFile) || is.null(point)){ #reading point from text file
    con <- file(inputFile,"r")
    #get the input file dimension
    dim <- length(unlist(strsplit(readLines(con,n=1)[1], " ")))
    paste("dimension read",dim)
    dim<-strtoi(dim, base = 0L)
    close(con)
    
    mat <-scan(inputFile) #get input data
    
    #check to make sure dimension is between 2 and 9
    if(!dim >= 2){
      stop(paste("point dimension on input file must be between 2 and 9",  "\n"))
    }
    
    mat2<- matrix(mat,ncol =dim, byrow = TRUE)
    point <- mat2
    dim= ncol(point)
    
    #check to make sure we have the required point for the number of dimension specify, hence Qhull will return an error
    numberOfPointRequired =dim +2
    
    if(length(point) < numberOfPointRequired){
      stop("You need at least ", numberOfPointRequired, " point for ", dim , "  dimension")
    }
    
    #create the max/min point vector to use
    maxPoint=c()
    minPoint=c()
    
    for(i in c(1:dim)){
      #get the max/min value for each column
      maxPoint[i] = max(point[,i])
      minPoint[i] = min(point[,i])
    }
    
    
    ## Make sure we have real-valued input
    storage.mode(point) <- "double"
    
  }else if(is.null(inputFile) && is.null(point) && !is.null(minPoint) && !is.null(maxPoint)){ #user generating  random grid by specifying a vector or minimum and maximum point
    
    #check to make sure max and min point are vector
    if(!is.vector(minPoint)){
      stop("you need to specify a vector of minimum point")
    }else if(!is.vector(maxPoint)){
      stop("you need to specify a vector of maxmum point")
    }
    
    
    if (length(minPoint) != length(maxPoint)) {
      stop("Length of min and max Point differ")
    }
    if (FALSE %in% (minPoint < maxPoint)) {
      stop("Maximum point not greater than minimum point in all dimension")
    }
    
    #check to make sure grid size is equal to the number of max/min point specify
    if(length(maxPoint) != nCoords && length(minPoint) != nCoords){
      stop("Length of Maximum and Minmum point must be equal to the number of nCoords specify")
    }
    
  }else if(is.null(minPoint) || is.null(maxPoint)){
    stop("Please specify both min and max vector points")
  }
  
  maxPoint=maxPoint + 0.3
  minPoint =minPoint -0.3
  
  result = list()
  
  for (n in seq(1, length(minPoint))) {
    result[[n]] = seq(minPoint[n], maxPoint[n], (maxPoint[n] - minPoint[n]) / (nCoords - 1))
  }
  # #mesh grid to coordinate
  return(as.matrix(expand.grid(result)))
  
}
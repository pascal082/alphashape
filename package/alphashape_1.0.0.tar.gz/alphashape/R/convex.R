##' @title Convex hull in N-dimensions. 
##' @description  This function calculates the  Convex hull in N-dimensions using the qhull library
##'
##' @param inputFile \code{inputFile} is an input file containing the point, where the first line is the number of dimension. 
##'
##' @param point \code{point} is an \code{n}-by-\code{dim} matrix. The rows of
##'   \code{point} represent \code{n} points in \code{dim}-dimensional
##'   space.
##' @param options String containing extra options for the underlying Qhull command.(See the Qhull documentation (\url{../doc/html/qdelaun.html}) for the available options.) The
##'   \code{Qbb} option is always passed to Qhull. The default options are \code{Qt}.  The degenerate (zero area) regions are returned
##'   For silent operation, specify the option \code{Pp}.
##' @seealso Used internally by \code{\link{convex}}
##' @example 
##' # define point
##' x = c(30,70,20,50,40,70)
##' y = c(35,80,70,50,60,20)
##' p = matrix(c(x,y), ncol=2)
##' convex =convex(point=p)
#' @export convex
  convex <- function(inputFile=NULL,point=NULL, options=NULL) {
	## Check directory writable
	tmpdir <- tempdir()
	## R should guarantee the tmpdir is writable, but check in any case
	if (file.access(tmpdir, 2) == -1) {
		stop(paste("Unable to write to R temporary directory", tmpdir, "\n"))
	}
	
	
	
	paste("reading inputFile",inputFile)
	## Coerce the input to be matrix
	if(is.null(inputFile)){
		if(is.null(point)){
			stop(paste("FIle name containing the point or point in n-dimension is needed", "\n"))
		}
		else if (is.data.frame(point)) {
			point <- as.matrix(point)
		}
	}else{
		
		con <- file(inputFile,"r")
		dim <- length(unlist(strsplit(readLines(con,n=1)[1], " ")))
		dim<-strtoi(dim, base = 0L)
		close(con)
		#check to make sure first line is between 2 and 9
		if(!dim >= 2){
			stop(paste("point dimension on input file must be at lease 2",  "\n"))
		}
		mat <- scan(inputFile)
	
		mat2<- matrix(mat,ncol =dim, byrow = TRUE)
		point <- mat2
	
		
		#check to make sure we have the required point for the number of dimension specify, hence Qhull will return an error
		numberOfPointRequired =dim +2
		if(length(point) < numberOfPointRequired){
			stop("You need at least ", numberOfPointRequired, " point for ", dim , "  dimension")
		}
		
	}
	
	## Make sure we have real-valued input
	storage.mode(point) <- "double"
	
	## We need to check for NAs in the input, as these will crash the C
	## code.
	if (any(is.na(point))) {
		stop("The first argument should not contain any NAs")
	}
	

	options <- "Qt"
	
	options <- paste(options, collapse=" ")
	
	## It is essential that delaunayn is called with either the QJ or Qt
	## option. Otherwise it may return a non-triangulated structure, i.e
	## one with more than dim+1 points per structure, where dim is the
	## dimension in which the points p reside.
	if (!grepl("Qt", options) & !grepl("QJ", options)) {
		options <- paste(options, "Qt")
	}

	
	ret <-.Call("C_convex", point, as.character(options), tmpdir, PACKAGE="alphashape")
	

	class(ret) <- "convexthull"
	

	ret$inputPoints =point
	
	return(ret)
}

library(testthat)
library(alphashape)

test_check("alphashape")
